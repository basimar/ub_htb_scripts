#!/bin/bash

# make-aleph-swa-firmen-und-verbaende.sh
#
# Aufbereitung der SWA "doksf" Aufnahmen inkl. Autoritätsaufnahmen
#
# Dokumentation:
#   http://ub-files.ub.unibas.ch/ordnungssystem/1_Eigene-Organisation/15_IT/153_Bibliothekssysteme/bibtools/hierarchie_toolbox/swa_firmen_und_verbaende/ANLE_SWA_Firmen_und_Verbaende_aufbereiten_20140604_ava.html
# 
# Input:   
#   swa-doksf.seq (Aleph Sequential, wcl=doksf)
#
# Output:  
#   kss-desk.txt: Konkordanz SWA-Deskriptoren    <-> Koerperschaftsnamen
#   kss-aut.txt:  Konkordanz Koerperschaftsnamen <-> ACCREF AUT
#
# history:
#   rev. 07.04.2016 andres.vonarx@unibas.ch

CLEANUP=1
MY_PATH="`dirname \"$0\"`"
MY_PATH="`( cd \"$MY_PATH\" && pwd )`"

echo "SWA Firmen- und Verbanddokumentation"
echo "------------------------------------"

printf "start: "
date

rm -f $MY_PATH/tmp/kss-aut.txt
rm -f $MY_PATH/tmp/kss-desk.txt
rm -f $MY_PATH/tmp/kss-lookup-errors.txt

if [ -f $dsv01_dev/dsv01/scratch/swa-doksf.seq ]; then
    echo "* Kopiere swa-doksf.seq"
    cp $dsv01_dev/dsv01/scratch/swa-doksf.seq $MY_PATH/tmp
else
    echo "kann dsv01/scratch/swa-doksf.seq nicht finden."
    echo "AGEBROCHEN."
    exit
fi


echo "* Konkordanz Koerperschaften und Deskriptoren"
perl $MY_PATH/bin/extract-firmen-deskriptoren.pl
sed 's/<<//g;s/>>//g' < $MY_PATH/tmp/kss-desk.tmp | sort -u > $MY_PATH/tmp/kss-desk.txt

echo "* extrahiere Körperschaften"
perl -p -e 's/^.*\|//' $MY_PATH/tmp/kss-desk.tmp | sort -u > $MY_PATH/tmp/kss.tmp

echo "* Konkordanz Koerperschaften und Normdateien"
perl $MY_PATH/bin/lookup_aut_accref.pl

if [ $CLEANUP == 1 ]; then
    rm -f $MY_PATH/tmp/kss-desk.tmp
    rm -f $MY_PATH/tmp/kss.tmp
    rm -f $MY_PATH/tmp/swa-doksf.seq
fi

printf "end: "
date
